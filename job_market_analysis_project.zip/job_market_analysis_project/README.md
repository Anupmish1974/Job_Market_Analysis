# Job Market Analysis and Recommendation System

## Overview
This project analyzes the supplied Upwork job-posting dataset, explores title/rate patterns, compares hourly rates by country, tracks monthly posting counts, detects remote-work keywords, and provides a content-based job recommendation prototype.

## Dataset
`data/job_postings.csv` is derived from the user-provided Excel file. It contains 244,828 records and these fields: `title`, `link`, `published_date`, `is_hourly`, `hourly_low`, `hourly_high`, `budget`, and `country`.

**Important limitations**
- The supplied data is a historical extract, not real-time data.
- Budgets and hourly rates are not guaranteed to use a common currency or represent employee salaries.
- Title-based categories and remote-work labels are heuristic.
- A short date window is insufficient to support confident long-term forecasts. The notebook reports this limitation instead of fabricating accuracy.
- Only authorized, legally accessible data sources should be used for future live updates.

## Quick start (local)
1. Install Python 3.10+.
2. Create a virtual environment (recommended).
3. Install dependencies:
   `pip install -r requirements.txt`
4. Run the notebook:
   `jupyter notebook Job_Market_Analysis.ipynb`
5. Run the dashboard:
   `streamlit run app.py`
6. In another terminal, run the API:
   `python api.py`

Dashboard: `http://localhost:8501`  
API health: `http://localhost:5000/health`  
API stats: `http://localhost:5000/stats`  
Recommendation example: `http://localhost:5000/recommend?q=Python%20developer&limit=10`

## Docker
Run `docker compose up --build`.  
Dashboard: `http://localhost:8501`  
API health: `http://localhost:5000/health`

## API reference
### `GET /health`
Returns service status and loaded record count.

### `GET /stats`
Returns record count, country count, rate availability, and date range.

### `GET /recommend?q=<skills or title>&limit=10&country=<optional>`
Returns ranked postings based on TF-IDF cosine similarity of job titles. `limit` is capped at 50. `q` is required.

## Analytical tasks mapped to the supplied brief
1. Job-title keywords and rates/budgets: notebook salary/budget summaries and charts.
2. Emerging categories: frequency tables and month-over-month changes, interpreted cautiously.
3. Demand prediction: time-ordered baseline evaluation when enough months exist; no unsupported accuracy claim for short samples.
4. Country hourly rates: country-level median/mean and minimum sample-size threshold.
5. Recommendations: TF-IDF content-based ranking in notebook, dashboard, and API.
6. Monthly dynamics: posting counts by month.
7. Remote work: keyword signal analysis, clearly marked as an approximation.
8. Future trends: transparent flat/continued-change scenarios, not causal predictions.

## Project files
- `Job_Market_Analysis.ipynb`: complete analytical notebook.
- `app.py`: Streamlit dashboard.
- `api.py`: Flask recommendation API.
- `data/job_postings.csv`: supplied data in portable CSV format.
- `reports/`: destination for exported analysis tables.
- `Dockerfile`, `docker-compose.yml`: container setup.


## Interpretation notes
The notebook contains Markdown explanations for the major tables and graphs and prints data-derived observations after key outputs. Run all cells to generate the actual figures and values.
