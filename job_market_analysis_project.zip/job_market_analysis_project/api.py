from flask import Flask, jsonify, request
import pandas as pd
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)
DATA_PATH = Path("data/job_postings.csv")
df = pd.read_csv(DATA_PATH)
df["title"] = df["title"].fillna("").astype(str)
df["country"] = df["country"].fillna("Unknown").astype(str)
df["published_date"] = pd.to_datetime(df["published_date"], errors="coerce", utc=True)
for c in ["hourly_low","hourly_high","budget"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")
df["hourly_mid"] = df[["hourly_low","hourly_high"]].mean(axis=1)
vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1,2), min_df=2, max_features=50000)
matrix = vectorizer.fit_transform(df["title"].str.lower())

@app.get("/health")
def health():
    return jsonify({"status":"ok","records":int(len(df))})

@app.get("/stats")
def stats():
    return jsonify({
        "records": int(len(df)),
        "countries": int(df.loc[df["country"].ne("Unknown"),"country"].nunique()),
        "hourly_records_with_rates": int((df["hourly_mid"].notna()).sum()),
        "date_min": str(df["published_date"].min()),
        "date_max": str(df["published_date"].max())
    })

@app.get("/recommend")
def recommend():
    query = request.args.get("q", "").strip()
    if not query:
        return jsonify({"error":"Required query parameter: q"}), 400
    try:
        n = max(1, min(int(request.args.get("limit", 10)), 50))
    except ValueError:
        return jsonify({"error":"limit must be an integer"}), 400
    country = request.args.get("country")
    scores = cosine_similarity(vectorizer.transform([query.lower()]), matrix).ravel()
    out = df.copy()
    out["similarity_score"] = scores
    if country:
        out = out[out["country"].str.casefold() == country.casefold()]
    out = out[out["similarity_score"] > 0].sort_values("similarity_score", ascending=False).head(n)
    out = out[["title","link","country","is_hourly","hourly_low","hourly_high","budget","similarity_score"]]
    out = out.astype(object).where(pd.notna(out), None)
    return jsonify({"query":query,"count":len(out),"recommendations":out.to_dict(orient="records")})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
