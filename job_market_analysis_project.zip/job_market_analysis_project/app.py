import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

st.set_page_config(page_title="Job Market Insights", page_icon="📊", layout="wide")
st.title("Job Market Analysis & Recommendation System")
st.caption("Exploratory insights from the supplied Upwork postings dataset. Not a live job feed.")

DATA = Path("data/job_postings.csv")
if not DATA.exists():
    st.error("Dataset not found. Put job_postings.csv inside the data/ folder.")
    st.stop()

@st.cache_data
def load_data():
    d = pd.read_csv(DATA)
    d["title"] = d["title"].fillna("").astype(str)
    d["country"] = d["country"].fillna("Unknown").astype(str)
    d["published_date"] = pd.to_datetime(d["published_date"], errors="coerce", utc=True)
    for c in ["hourly_low","hourly_high","budget"]:
        d[c] = pd.to_numeric(d[c], errors="coerce")
    d["hourly_mid"] = d[["hourly_low","hourly_high"]].mean(axis=1)
    d["month"] = d["published_date"].dt.strftime("%Y-%m")
    d["title_clean"] = d["title"].str.lower()
    return d
df = load_data()

groups = {
"Software / Development":["developer","software","programmer","web app","full stack","backend","frontend","python","javascript"],
"Design / Creative":["designer","design","logo","illustration","video editor","animation","graphic"],
"Writing / Translation":["writer","writing","copywriter","content","translation","proofread"],
"Marketing / Sales":["marketing","seo","social media","ads","sales","lead generation","media buyer"],
"Data / AI":["data","machine learning","artificial intelligence","ai ","analytics","dashboard"],
"Admin / Support":["virtual assistant","customer support","administrative","data entry","assistant"],
"Finance / Accounting":["accountant","bookkeeping","finance","tax","financial"]}
def category(title):
    t = str(title).lower()
    for k, terms in groups.items():
        if any(x in t for x in terms): return k
    return "Other / Unclassified"
df["category"] = df["title"].map(category)
df["is_hourly"] = df["is_hourly"].astype(str).str.lower().isin(["true","1"])
df["remote_signal"] = df["title_clean"].str.contains(r"\b(remote|work from home|wfh|anywhere|distributed|virtual)\b", regex=True, na=False)

with st.sidebar:
    st.header("Filters")
    cats = st.multiselect("Job category", sorted(df["category"].unique()), default=sorted(df["category"].unique()))
    countries = sorted(df["country"].unique())
    selected_countries = st.multiselect("Country", countries)
    hourly_only = st.checkbox("Hourly postings only", value=False)
filtered = df[df["category"].isin(cats)]
if selected_countries: filtered = filtered[filtered["country"].isin(selected_countries)]
if hourly_only: filtered = filtered[filtered["is_hourly"]]

c1,c2,c3,c4 = st.columns(4)
c1.metric("Postings", f"{len(filtered):,}")
c2.metric("Countries (incl. unknown)", f"{filtered['country'].nunique():,}")
c3.metric("Hourly postings", f"{int(filtered['is_hourly'].sum()):,}")
c4.metric("Remote title signals", f"{int(filtered['remote_signal'].sum()):,}")

tab1,tab2,tab3,tab4 = st.tabs(["Market overview","Rates & countries","Remote signals","Job recommendations"])
with tab1:
    monthly = filtered.dropna(subset=["published_date"]).groupby("month").size().rename("postings").reset_index()
    if not monthly.empty:
        st.plotly_chart(px.line(monthly,x="month",y="postings",markers=True,title="Monthly posting volume"),use_container_width=True)
    cat_counts = filtered.groupby("category").size().sort_values(ascending=False).reset_index(name="postings")
    st.plotly_chart(px.bar(cat_counts,x="postings",y="category",orientation="h",title="Postings by title category"),use_container_width=True)
with tab2:
    rates = filtered[filtered["is_hourly"] & filtered["hourly_mid"].notna() & filtered["country"].ne("Unknown")]
    country_rates = rates.groupby("country").agg(postings=("hourly_mid","size"),median_rate=("hourly_mid","median"),mean_rate=("hourly_mid","mean")).query("postings >= 10").sort_values("median_rate",ascending=False).reset_index()
    st.caption("Currency is not explicitly normalized in the source data; compare cautiously.")
    if not country_rates.empty:
        st.plotly_chart(px.bar(country_rates.head(25),x="median_rate",y="country",orientation="h",hover_data=["postings","mean_rate"],title="Median hourly midpoint by country (minimum 10 postings)"),use_container_width=True)
    else: st.info("Not enough hourly rate data for the selected filters.")
with tab3:
    remote = filtered.groupby("category")["remote_signal"].agg(["sum","count","mean"]).reset_index()
    remote["share_pct"] = remote["mean"]*100
    st.dataframe(remote, use_container_width=True)
    st.warning("Remote work is inferred from title keywords only; the dataset does not contain a verified remote-work field.")
with tab4:
    query = st.text_input("Enter skills or a target job title", placeholder="e.g., Python developer, logo design, SEO")
    country = st.selectbox("Country filter (optional)", ["Any country"] + sorted(df["country"].unique().tolist()))
    n = st.slider("Number of recommendations", 5, 20, 10)
    if st.button("Recommend jobs") and query.strip():
        @st.cache_resource
        def make_index(titles):
            v = TfidfVectorizer(stop_words="english", ngram_range=(1,2), min_df=2, max_features=50000)
            matrix = v.fit_transform(titles)
            return v, matrix
        try:
            vec, matrix = make_index(tuple(df["title"].fillna("").astype(str).str.lower()))
            scores = cosine_similarity(vec.transform([query.lower()]), matrix).ravel()
            rec = df.copy()
            rec["similarity_score"] = scores
            if country != "Any country": rec = rec[rec["country"] == country]
            rec = rec[rec["similarity_score"] > 0].sort_values("similarity_score",ascending=False).head(n)
            st.dataframe(rec[["title","country","is_hourly","hourly_low","hourly_high","budget","published_date","link","similarity_score"]],use_container_width=True)
        except ValueError:
            st.error("Not enough text variation to build the recommendation index.")
st.divider()
st.caption("Data period is limited to the supplied file. The dashboard does not fetch live postings.")
