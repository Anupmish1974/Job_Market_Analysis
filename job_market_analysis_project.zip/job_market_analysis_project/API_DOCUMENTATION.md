# API Documentation

Base URL (local): `http://localhost:5000`

## Health check
`GET /health`

Example response:
```json
{"status":"ok","records":244828}
```

## Dataset summary
`GET /stats`

Fields: `records`, `countries`, `hourly_records_with_rates`, `date_min`, `date_max`.

## Job recommendations
`GET /recommend?q=python%20developer&limit=10`
Optional: `country=United%20States`

- `q` (required): free-text target title or skills.
- `limit` (optional): 1–50; defaults to 10.
- `country` (optional): case-insensitive exact country filter.

Response fields include title, link, country, hourly flag, hourly range, budget, and similarity score. Scores are text similarity rankings, not a probability that the job is suitable.
