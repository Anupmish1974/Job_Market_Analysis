# Job Market Analysis and Recommendation System
## Project Report

### 1. Introduction
Online freelance postings provide signals about requested skills, offered budgets, advertised hourly rates, and geographic distribution. This project applies data analysis and a content-based recommendation prototype to a supplied historical extract of Upwork postings.

### 2. Objectives
- Explore job-title language in relation to advertised hourly rates and fixed-price budgets.
- Summarize posting frequency by interpretable title categories.
- Compare observed category counts over time and evaluate whether the sample supports forecasting.
- Compare hourly-rate summaries across countries.
- Prototype a job recommendation engine.
- Summarize monthly activity and title-based remote-work signals.
- Present transparent future scenarios while documenting uncertainty.

### 3. Data and methodology
The input contains 244,828 rows and eight fields: title, link, published date, hourly flag, low/high hourly rates, budget, and country. Preparation includes date parsing, numeric conversion, missing-value handling, title normalization, and derived hourly midpoints. Categories are assigned using documented keyword rules. The recommender uses TF-IDF vectorization and cosine similarity on job titles.

### 4. Analysis plan
The notebook creates data-quality summaries, category counts, keyword/rate summaries, country rate comparisons, monthly time series, remote keyword summaries, and recommendation examples. Forecast evaluation uses a chronological holdout and a simple naive baseline only if there are enough distinct months.

### 5. Findings and interpretation
Run `Job_Market_Analysis.ipynb` to generate the exact numeric results and charts from the included dataset. The results are deliberately not hard-coded into this report so that they remain reproducible and traceable to the source file. The notebook exports analysis tables into `reports/`.

### 6. Limitations
- The file is a historical extract, not a real-time feed.
- The date window is short and cannot establish long-run trends.
- Freelance job budgets are not the same as employee salaries.
- Currency units may be missing or inconsistent; country rate comparisons must be treated cautiously.
- Title-based job categories are heuristic and may overlap conceptually.
- Remote status is inferred from title text, not a verified field.
- Recommendations rank text similarity; they do not measure job quality or guarantee a match.

### 7. Conclusion
The project delivers a reproducible analysis notebook, an interactive dashboard, a Flask recommendation API, and Docker configuration. A production-grade real-time version would require an authorized data source, a scheduled refresh pipeline, currency normalization, stronger occupation taxonomy, and a longer historical series for forecasting.


## 8. Graph and output interpretation guide
- **Hourly-rate category bar chart:** compares median advertised hourly midpoints among categories with rate data. It is not an employee salary comparison and may be affected by unnormalized currencies and different sample sizes.
- **Monthly category line chart:** shows category posting counts over the observed months. Changes are descriptive and do not establish sustained market growth.
- **Country hourly-rate bar chart:** compares median hourly midpoints for countries meeting the minimum sample threshold. It is not a cost-of-living-adjusted comparison.
- **Monthly total posting chart:** shows how many dated rows occur in each month of the provided file; it cannot explain causes of peaks or dips.
- **Remote work table:** identifies titles containing remote-related keywords. It is only a proxy because the dataset has no verified remote-work field.
- **Forecast evaluation table:** MAE and RMSE measure holdout errors; compare the Random Forest with the naive previous-week baseline before judging usefulness.
- **Recommendation results:** cosine similarity ranks text similarity and is not a probability of hiring or a quality score.
- **Future scenario table:** flat and continued-change scenarios are simple illustrative baselines, not guarantees or causal predictions.

The notebook now includes Markdown explanations and automatically printed, data-derived observations beside key results. Exact findings should be read from the notebook outputs after running all cells; they are not fabricated or hard-coded in advance.
